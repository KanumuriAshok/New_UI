import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-handeling',
  templateUrl: './project-handeling.component.html',
  styleUrls: ['./project-handeling.component.css']
})
export class ProjectHandelingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
