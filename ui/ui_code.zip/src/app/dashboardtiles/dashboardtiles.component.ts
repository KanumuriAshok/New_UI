import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboardtiles',
  templateUrl: './dashboardtiles.component.html',
  styleUrls: ['./dashboardtiles.component.css']
})
export class DashboardtilesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
