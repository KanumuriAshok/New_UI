export const environment = {
  production: true,
  // api: 'https://45.35.14.204',
  // api : 'https://hldlld.seekerstops.com' // live server url
  api : 'http://172.16.4.53'  //cyient server url
};
