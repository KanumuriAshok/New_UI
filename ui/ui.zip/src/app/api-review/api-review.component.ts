import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-api-review',
  templateUrl: './api-review.component.html',
  styleUrls: ['./api-review.component.css']
})
export class ApiReviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
