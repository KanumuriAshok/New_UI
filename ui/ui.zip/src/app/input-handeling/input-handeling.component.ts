import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-handeling',
  templateUrl: './input-handeling.component.html',
  styleUrls: ['./input-handeling.component.css'],
})
export class InputHandelingComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
